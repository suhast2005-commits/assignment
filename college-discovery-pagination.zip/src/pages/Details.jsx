
import React from 'react';
import { useParams, Link } from 'react-router-dom';
import colleges from '../data/colleges';

export default function Details(){
 const {id}=useParams();
 const c=colleges.find(x=>x.id===Number(id));
 return <div className='container'>
 <Link to='/'>← Back</Link>
 <h1>{c.name}</h1>
 <p>Location: {c.location}</p>
 <p>Fees: ₹{c.fees}</p>
 <p>Rating: {c.rating}</p>
 <p>Overview, Courses, Placements and Reviews section placeholder.</p>
 </div>
}
