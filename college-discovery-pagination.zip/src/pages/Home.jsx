
import React,{useState} from 'react';
import { Link } from 'react-router-dom';
import colleges from '../data/colleges';

export default function Home(){
 const [search,setSearch]=useState('');
 const [location,setLocation]=useState('All');
 const [rating,setRating]=useState(0);
 const [maxFees,setMaxFees]=useState(999999);
 const [page,setPage]=useState(1);

 const filtered=colleges.filter(c=>
 c.name.toLowerCase().includes(search.toLowerCase()) &&
 (location==='All' || c.location===location) &&
 c.rating >= Number(rating) &&
 c.fees <= Number(maxFees)
 );

 const perPage=8;
 const totalPages=Math.ceil(filtered.length/perPage);
 const current=filtered.slice((page-1)*perPage,page*perPage);

 return (
 <div className='container'>
 <h1>College Discovery Platform</h1>

 <div className='filters'>
 <input placeholder='Search college' value={search} onChange={e=>{setSearch(e.target.value);setPage(1)}}/>
 <select onChange={e=>{setLocation(e.target.value);setPage(1)}}>
 <option>All</option><option>Chennai</option><option>Mumbai</option><option>Delhi</option><option>Bangalore</option>
 </select>

 <select onChange={e=>{setRating(e.target.value);setPage(1)}}>
 <option value='0'>All Ratings</option>
 <option value='4.5'>4.5+</option>
 <option value='4.8'>4.8+</option>
 </select>

 <select onChange={e=>{setMaxFees(e.target.value);setPage(1)}}>
 <option value='999999'>Any Fees</option>
 <option value='200000'>Under 2 Lakhs</option>
 <option value='250000'>Under 2.5 Lakhs</option>
 </select>
 </div>

 <div className='grid'>
 {current.map(c=>(
 <div className='card' key={c.id}>
 <h3>{c.name}</h3>
 <p>{c.location}</p>
 <p>₹{c.fees.toLocaleString()}</p>
 <p>⭐ {c.rating}</p>
 <Link to={'/college/'+c.id}>View Details</Link>
 </div>
 ))}
 </div>

 <div className='pagination'>
 <button disabled={page===1} onClick={()=>setPage(page-1)}>Prev</button>
 <span> Page {page} of {totalPages} </span>
 <button disabled={page===totalPages} onClick={()=>setPage(page+1)}>Next</button>
 </div>
 </div>
 )
}
